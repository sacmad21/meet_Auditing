import { useEffect, useRef } from "react";
import * as SpeechSDK from "microsoft-cognitiveservices-speech-sdk";
import { useMeeting } from "../contexts/MeetingContext";
import { getLanguageCode, translateText } from "../utils/languageUtils";

const TranscriptionHandler = ({ onAudioReady }) => {
  const {
    recordingStatus,
    selectedLanguage,
    addTranscript
  } = useMeeting();

  const recognizerRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const audioStreamRef = useRef(null);

  useEffect(() => {
    if (recordingStatus === "recording") {
      startRecording();
    } else if (recordingStatus === "paused") {
      stopRecognizer(); // pause transcription, keep recording if needed
    } else if (recordingStatus === "stopped") {
      stopAll(); // stop everything
    }

    return () => {
      stopAll();
    };
  }, [recordingStatus]);

  const startRecording = async () => {
    // Start MediaRecorder
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    audioStreamRef.current = stream;

    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;
    audioChunksRef.current = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) {
        audioChunksRef.current.push(e.data);
      }
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
      const blobUrl = URL.createObjectURL(blob);
      if (onAudioReady) {
        onAudioReady(blobUrl);
      }
    };

    mediaRecorder.start();

    // Start Azure Recognizer
    const speechConfig = SpeechSDK.SpeechConfig.fromSubscription(
      process.env.REACT_APP_AZURE_SPEECH_KEY,
      process.env.REACT_APP_AZURE_REGION
    );

    speechConfig.speechRecognitionLanguage = "en-US";
    speechConfig.setProperty(SpeechSDK.PropertyId.SpeechServiceConnection_ConversationTranscriptionEnabled, "true");

    const audioConfig = SpeechSDK.AudioConfig.fromDefaultMicrophoneInput();
    const recognizer = new SpeechSDK.ConversationTranscriber(speechConfig, audioConfig);
    recognizerRef.current = recognizer;

    recognizer.transcribed = async (s, e) => {
      const text = e.result?.text?.trim();
      const speakerId = e.result?.speakerId ?? 0;

      if (text) {
        const langCode = getLanguageCode(selectedLanguage);
        const translatedText = await translateText(text, langCode);
        addTranscript(text, speakerId, translatedText);
      }
    };

    recognizer.startTranscribingAsync();
  };

  const stopRecognizer = () => {
    if (recognizerRef.current) {
      recognizerRef.current.stopTranscribingAsync(() => {}, () => {});
    }
  };

  const stopAll = () => {
    stopRecognizer();

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }

    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach(track => track.stop());
    }

    recognizerRef.current = null;
    mediaRecorderRef.current = null;
    audioStreamRef.current = null;
  };

  return null; // No visible UI
};

export default TranscriptionHandler;
